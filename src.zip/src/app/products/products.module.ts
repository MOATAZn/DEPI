import { NgModule , CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllProductsComponent } from './components/all-products/all-products.component';
import { ProductsDetailsComponent } from './components/products-details/products-details.component';
import { SpinnerComponent } from '../shared/components/spinner/spinner.component';
import { SharedModule } from '../shared/shared.module';
import { PeoductComponent } from './components/product/peoduct.component'; 



@NgModule({
  declarations: [
    SpinnerComponent,
    
  ],
  imports: [
    CommonModule,
    AllProductsComponent
  ],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA] 

})
export class ProductsModule { }
