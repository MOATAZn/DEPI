import { Component } from '@angular/core';
import { ProductsService } from '../../services/products.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { RouterModule } from '@angular/router';
import { PeoductComponent } from '../product/peoduct.component';



@Component({
  selector: 'app-all-products',
  standalone: true,
  imports: [CommonModule, SharedModule, PeoductComponent,RouterModule ],
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.scss']
})


export class AllProductsComponent {
  products: any[] = [];
  categories: any[] = [];
  cartProducts: any[] = [];
  loading: boolean = false;
  constructor(private service: ProductsService, private router: Router) {
  }

  ngOnInit(): void {
    this.getProducts();
    this.getcatogories();
  }

  getProducts() {
    this.loading = true
    this.service.getAllProducts().subscribe(
      (res: any) => {
        console.log(res);
        this.products = res;
        this.loading = false

      },
      error => {
        // Navigate to the error page
        this.router.navigate(['/error']);
        this.loading = false


      }
    );
  }

  getcatogories() {
    this.loading = true

    this.service.getAllCategories().subscribe(
      (res: any) => {
        this.loading = false

        console.log(res);
        this.categories = res;
      },
      error => {

        // Navigate to the error page
        this.router.navigate(['/error']);
      }
    );
  }


  filterCategory(event: any) {
    let value = event.target.value;
    (value == "All") ? this.getProducts() : this.getProductsCategory(value);
  }

  getProductsCategory(keyword: any) {
    this.loading = true

    this.service.getProductsByCategory(keyword).subscribe(
      (res: any) => {
        this.loading = false

        console.log(res);
        this.products = res;
      },
      error => {
        this.router.navigate(['/error']);
      }
    );
  }

  addToCart(event: any) {
    if ("cart" in localStorage) {
      this.cartProducts = JSON.parse(localStorage.getItem('cart')!);
      this.checkForExisting(event)
    }
    else {
      this.cartProducts.push(event);
      localStorage.setItem('cart', JSON.stringify(this.cartProducts));
    }
  }


  showModal: boolean = false;

  checkForExisting(event: any) {
    let exist = this.cartProducts.find(p => p.item.id === event.item.id);

    if (exist) {
      // Show the modal
      this.showModal = true;

      // Hide the modal after 2 seconds
      setTimeout(() => {
        this.hideModal();
      }, 6000);
    } else {
      this.cartProducts.push(event);
      localStorage.setItem('cart', JSON.stringify(this.cartProducts));
    }
  }

  hideModal() {
    this.showModal = false;
  }

}
