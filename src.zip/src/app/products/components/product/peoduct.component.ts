import { Component, Input, Output, EventEmitter, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { RouterModule } from '@angular/router';



@Component({
  selector: 'app-peoduct',
  standalone: true,
  imports: [CommonModule, SharedModule,RouterModule],
  templateUrl: './peoduct.component.html',
  styleUrls: ['./peoduct.component.scss']
})
export class PeoductComponent {
  @Input() data: any = {};
  @Output() item = new EventEmitter()

  addButton: boolean = false;
  amount: number = 0;

  add() {
    this.item.emit({item:this.data , quantity: this.amount});
    this.addButton =false;
  }
}
