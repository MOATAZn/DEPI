import { Component, EventEmitter, Output, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductsService } from '../../services/products.service';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';

@Component({
  selector: 'app-products-details',
  standalone: true,
  imports: [CommonModule, SharedModule],
  templateUrl: './products-details.component.html',
  styleUrls: ['./products-details.component.scss']
})
export class ProductsDetailsComponent {
  id: any;
  loading: boolean = false;
  @Input() data: any = {};
  
  @Output() item = new EventEmitter<{ item: any }>(); // Emit the item and quantity
  addButton: boolean = false; // Toggle button visibility

  constructor(private route: ActivatedRoute, private service: ProductsService) {
    this.id = this.route.snapshot.paramMap.get('id');
  }

  ngOnInit(): void {
    this.getProduct();
  }

  getProduct() {
    this.loading = true;
    this.service.getProductById(this.id).subscribe(res => {
      this.data = res;
      this.loading = false;
    });
  }

  // Method to emit the selected item and its quantity
  add() {
    this.item.emit({ item: this.data });
    this.addButton = false; // Reset button visibility
  }
}
