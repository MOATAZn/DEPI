import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartComponent } from './components/cart/cart.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule } from '@angular/forms';
import { CheckoutComponent } from './components/cart/checkout/checkout.component';




@NgModule({
  declarations: [
    CartComponent,
    CheckoutComponent,
  
  ],
  imports: [
    CommonModule,FormsModule
    
  ]
})
export class CartsModule { }
