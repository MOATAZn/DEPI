import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent {
  // Model for form data
  formData = {
    fullName: '',
    email: '',
    address: '',
    city: '',
    country: '',
    postalCode: '',
    cardName: '',
    cardNumber: '',
    expMonth: '',
    expYear: '',
    cvv: ''
  };

  // Form submit handler
  onSubmit(form: any) {
    if (form.valid) {
      console.log('Form Submitted', this.formData);
    } else {
      console.log('Form is invalid');
    }
  }
}
