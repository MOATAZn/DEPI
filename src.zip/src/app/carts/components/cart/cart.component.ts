import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';


@Component({
  selector: 'app-cart',
  standalone : true,
  imports : [ CommonModule,FormsModule,RouterModule ],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent {
  cartProducts: any[] = [];

  ngOnInit() {
    this.getCartProducts();
  }

  // Fetch cart products from localStorage
  getCartProducts() {
    if ("cart" in localStorage) {
      this.cartProducts = JSON.parse(localStorage.getItem('cart')!);
    }
    console.log(this.cartProducts);
  }

  // Function to calculate the total price of the cart
  getTotalPrice(): number {
    return this.cartProducts.reduce((total, item) => {
      return total + (item.quantity * item.item.price);
    }, 0);
  }

  // Function to increase quantity and update localStorage
  increaseQuantity(item: any) {
    item.quantity++;
    this.updateCartInLocalStorage();
  }

  // Function to decrease quantity and update localStorage
  decreaseQuantity(item: any) {
    if (item.quantity > 1) {
      item.quantity--;
      this.updateCartInLocalStorage();
    }
  }


  // Function to remove a product from the cart
  removeItem(item: any) {
    this.cartProducts = this.cartProducts.filter(product => product.item.id !== item.item.id);
    this.updateCartInLocalStorage();  // Update localStorage after removing the item
  }

  clearCart() {
    this.cartProducts = []; // Clear cartProducts array
    localStorage.removeItem('cart'); // Remove 'cart' from localStorage
  }

    // Update the cart in localStorage
    updateCartInLocalStorage() {
      localStorage.setItem('cart', JSON.stringify(this.cartProducts));
    }
    

}
