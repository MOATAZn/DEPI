import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { SharedModule } from './shared/shared.module';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'E_Commerce';
  showNav = true; // Flag to show/hide the navigation
  showFooter = true;

  constructor(private router: Router) {}

  ngOnInit(): void {

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        if (event.url === '/error' || event.url ==='/form' || event.url ==='/carts') {
          this.showFooter=false;
        }
        else {
          this.showFooter = true; // Show navigation on all other pages
        }

        if (event.url === '/error') {
          this.showNav = false; // Hide navigation on error page
        } else {
          this.showNav = true; // Show navigation on all other pages
        }
      }
    });
  }

}
